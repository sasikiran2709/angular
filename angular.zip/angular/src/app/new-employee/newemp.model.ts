export class newemp{
    constructor(public Eid:any,public name:string,public cell:string,public email:string,public exp:any){}
    
}
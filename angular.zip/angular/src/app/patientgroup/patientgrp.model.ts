export class patientgrp{
    constructor(public Pid:number,
        public fname:string,
        public lname:string,
        public bggroup:string,
        public disease:string,
        public age:number){}
}
export class bg_list
{
    constructor( public  bg_id:number,public  bg_name:string)
    {
        
    }
}
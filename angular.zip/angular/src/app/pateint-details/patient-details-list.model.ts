export class patient_Details{
    constructor(public Pid:number,public fname:string,public Lname:string,public age:number,public bg_id:number){}
}
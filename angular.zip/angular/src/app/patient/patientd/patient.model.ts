export class patientd{
    constructor(public PId:number,public FName:string,public LName:string,public bg:string){    }
}